import React, { useState, useEffect } from "react";
import { BrowserProvider, Contract, ethers } from "ethers";
import { useNavigate } from "react-router-dom";
import { 
    Box, 
    Container, 
    Typography, 
    Button, 
    Grid, 
    Card, 
    CardContent, 
    CardActions, 
    TextField, 
    Dialog, 
    DialogTitle, 
    DialogContent, 
    DialogActions, 
    DialogContentText,
    AppBar, 
    Toolbar, 
    IconButton, 
    MenuItem, 
    Select, 
    FormControl, 
    InputLabel,
    Paper,
    Chip,
    Avatar,
    CircularProgress,
    Divider,
    Alert,
    Snackbar,
    Tab,
    Tabs,
    Stack,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Badge
} from '@mui/material';
import { 
    Add as AddIcon, 
    Logout as LogoutIcon, 
    Person as PersonIcon, 
    FilterList as FilterListIcon,
    Agriculture as AgricultureIcon,
    AttachMoney as AttachMoneyIcon,
    CalendarMonth as CalendarMonthIcon,
    Inventory as InventoryIcon,
    CloudUpload as CloudUploadIcon,
    Image as ImageIcon,
    Close as CloseIcon,
    CheckCircle as CheckCircleIcon,
    Cancel as CancelIcon,
    Notifications as NotificationsIcon,
    ShoppingCart as ShoppingCartIcon,
    LocalShipping as LocalShippingIcon,
    BugReport as BugReportIcon
} from '@mui/icons-material';
import { uploadImageToPinata, getIPFSGatewayURL } from '../services/pinataService';
import { getUserDisplayName, getProfileImageUrl } from '../services/profileService';
import Web3 from 'web3';
import { motion } from "framer-motion";
import { useTheme } from "../components/theme-provider";
import { ThemeToggle } from "../components/theme-toggle";

const CONTRACT_ADDRESS = "0x0e5951144d4d18F8771e3F15BFC3aB4e2ba2d8A2";

const CONTRACT_ABI = [
    {
      "anonymous": false,
      "inputs": [
        {
          "indexed": true,
          "internalType": "address",
          "name": "buyer",
          "type": "address"
        },
        {
          "indexed": true,
          "internalType": "address",
          "name": "farmer",
          "type": "address"
        },
        {
          "indexed": false,
          "internalType": "uint256",
          "name": "cropID",
          "type": "uint256"
        },
        {
          "indexed": false,
          "internalType": "uint256",
          "name": "quantity",
          "type": "uint256"
        },
        {
          "indexed": false,
          "internalType": "uint256",
          "name": "amountHeld",
          "type": "uint256"
        }
      ],
      "name": "CropBought",
      "type": "event"
    },
    {
      "anonymous": false,
      "inputs": [
        {
          "indexed": true,
          "internalType": "address",
          "name": "farmer",
          "type": "address"
        },
        {
          "indexed": false,
          "internalType": "string",
          "name": "cropName",
          "type": "string"
        },
        {
          "indexed": false,
          "internalType": "uint256",
          "name": "price",
          "type": "uint256"
        },
        {
          "indexed": false,
          "internalType": "uint256",
          "name": "cropID",
          "type": "uint256"
        },
        {
          "indexed": false,
          "internalType": "uint256",
          "name": "quantity",
          "type": "uint256"
        },
        {
          "indexed": false,
          "internalType": "string",
          "name": "deliveryDate",
          "type": "string"
        },
        {
          "indexed": false,
          "internalType": "string",
          "name": "imageCID",
          "type": "string"
        }
      ],
      "name": "CropListed",
      "type": "event"
    },
    {
      "anonymous": false,
      "inputs": [
        {
          "indexed": true,
          "internalType": "address",
          "name": "buyer",
          "type": "address"
        },
        {
          "indexed": true,
          "internalType": "address",
          "name": "farmer",
          "type": "address"
        },
        {
          "indexed": false,
          "internalType": "uint256",
          "name": "cropID",
          "type": "uint256"
        },
        {
          "indexed": false,
          "internalType": "uint256",
          "name": "amountReleased",
          "type": "uint256"
        }
      ],
      "name": "DeliveryConfirmed",
      "type": "event"
    },
    {
      "anonymous": false,
      "inputs": [
        {
          "indexed": true,
          "internalType": "uint256",
          "name": "requestId",
          "type": "uint256"
        },
        {
          "indexed": true,
          "internalType": "address",
          "name": "buyer",
          "type": "address"
        },
        {
          "indexed": true,
          "internalType": "address",
          "name": "farmer",
          "type": "address"
        },
        {
          "indexed": false,
          "internalType": "uint256",
          "name": "cropID",
          "type": "uint256"
        },
        {
          "indexed": false,
          "internalType": "uint256",
          "name": "quantity",
          "type": "uint256"
        }
      ],
      "name": "PurchaseRequested",
      "type": "event"
    },
    {
      "anonymous": false,
      "inputs": [
        {
          "indexed": true,
          "internalType": "uint256",
          "name": "requestId",
          "type": "uint256"
        },
        {
          "indexed": false,
          "internalType": "enum FarmerPortal.RequestStatus",
          "name": "status",
          "type": "uint8"
        }
      ],
      "name": "RequestStatusChanged",
      "type": "event"
    },
    {
      "anonymous": false,
      "inputs": [
        {
          "indexed": true,
          "internalType": "address",
          "name": "user",
          "type": "address"
        },
        {
          "indexed": false,
          "internalType": "string",
          "name": "name",
          "type": "string"
        },
        {
          "indexed": false,
          "internalType": "string",
          "name": "profileImageCID",
          "type": "string"
        }
      ],
      "name": "UserProfileUpdated",
      "type": "event"
    },
    {
      "anonymous": false,
      "inputs": [
        {
          "indexed": true,
          "internalType": "address",
          "name": "user",
          "type": "address"
        },
        {
          "indexed": false,
          "internalType": "enum FarmerPortal.UserRole",
          "name": "role",
          "type": "uint8"
        }
      ],
      "name": "UserRegistered",
      "type": "event"
    },
    {
      "inputs": [
        {
          "internalType": "address",
          "name": "",
          "type": "address"
        }
      ],
      "name": "escrowBalances",
      "outputs": [
        {
          "internalType": "uint256",
          "name": "",
          "type": "uint256"
        }
      ],
      "stateMutability": "view",
      "type": "function",
      "constant": true
    },
    {
      "inputs": [
        {
          "internalType": "address",
          "name": "",
          "type": "address"
        }
      ],
      "name": "users",
      "outputs": [
        {
          "internalType": "address",
          "name": "wallet",
          "type": "address"
        },
        {
          "internalType": "enum FarmerPortal.UserRole",
          "name": "role",
          "type": "uint8"
        },
        {
          "internalType": "bool",
          "name": "registered",
          "type": "bool"
        },
        {
          "internalType": "string",
          "name": "name",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "profileImageCID",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "location",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "contact",
          "type": "string"
        }
      ],
      "stateMutability": "view",
      "type": "function",
      "constant": true
    },
    {
      "inputs": [
        {
          "internalType": "uint8",
          "name": "role",
          "type": "uint8"
        }
      ],
      "name": "registerUser",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "string",
          "name": "_name",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "_profileImageCID",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "_location",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "_contact",
          "type": "string"
        }
      ],
      "name": "updateUserProfile",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "address",
          "name": "_userAddress",
          "type": "address"
        }
      ],
      "name": "getUserProfile",
      "outputs": [
        {
          "internalType": "string",
          "name": "",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "",
          "type": "string"
        },
        {
          "internalType": "enum FarmerPortal.UserRole",
          "name": "",
          "type": "uint8"
        }
      ],
      "stateMutability": "view",
      "type": "function",
      "constant": true
    },
    {
      "inputs": [
        {
          "internalType": "string",
          "name": "_cropName",
          "type": "string"
        },
        {
          "internalType": "uint256",
          "name": "_price",
          "type": "uint256"
        },
        {
          "internalType": "uint256",
          "name": "_cropID",
          "type": "uint256"
        },
        {
          "internalType": "uint256",
          "name": "_quantity",
          "type": "uint256"
        },
        {
          "internalType": "string",
          "name": "_deliveryDate",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "_imageCID",
          "type": "string"
        }
      ],
      "name": "addListing",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "inputs": [],
      "name": "getMyListings",
      "outputs": [
        {
          "components": [
            {
              "internalType": "string",
              "name": "cropName",
              "type": "string"
            },
            {
              "internalType": "uint256",
              "name": "price",
              "type": "uint256"
            },
            {
              "internalType": "uint256",
              "name": "cropID",
              "type": "uint256"
            },
            {
              "internalType": "uint256",
              "name": "quantity",
              "type": "uint256"
            },
            {
              "internalType": "string",
              "name": "deliveryDate",
              "type": "string"
            },
            {
              "internalType": "address",
              "name": "farmer",
              "type": "address"
            },
            {
              "internalType": "string",
              "name": "imageCID",
              "type": "string"
            }
          ],
          "internalType": "struct FarmerPortal.CropListing[]",
          "name": "",
          "type": "tuple[]"
        }
      ],
      "stateMutability": "view",
      "type": "function",
      "constant": true
    },
    {
      "inputs": [
        {
          "internalType": "address",
          "name": "_user",
          "type": "address"
        }
      ],
      "name": "getUserRole",
      "outputs": [
        {
          "internalType": "enum FarmerPortal.UserRole",
          "name": "",
          "type": "uint8"
        }
      ],
      "stateMutability": "view",
      "type": "function",
      "constant": true
    },
    {
      "inputs": [],
      "name": "getAllListings",
      "outputs": [
        {
          "components": [
            {
              "internalType": "string",
              "name": "cropName",
              "type": "string"
            },
            {
              "internalType": "uint256",
              "name": "price",
              "type": "uint256"
            },
            {
              "internalType": "uint256",
              "name": "cropID",
              "type": "uint256"
            },
            {
              "internalType": "uint256",
              "name": "quantity",
              "type": "uint256"
            },
            {
              "internalType": "string",
              "name": "deliveryDate",
              "type": "string"
            },
            {
              "internalType": "address",
              "name": "farmer",
              "type": "address"
            },
            {
              "internalType": "string",
              "name": "imageCID",
              "type": "string"
            }
          ],
          "internalType": "struct FarmerPortal.CropListing[]",
          "name": "",
          "type": "tuple[]"
        }
      ],
      "stateMutability": "view",
      "type": "function",
      "constant": true
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "cropID",
          "type": "uint256"
        },
        {
          "internalType": "uint256",
          "name": "quantity",
          "type": "uint256"
        },
        {
          "internalType": "string",
          "name": "message",
          "type": "string"
        }
      ],
      "name": "requestPurchase",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "requestId",
          "type": "uint256"
        },
        {
          "internalType": "bool",
          "name": "accept",
          "type": "bool"
        }
      ],
      "name": "respondToPurchaseRequest",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "requestId",
          "type": "uint256"
        }
      ],
      "name": "completePurchase",
      "outputs": [],
      "stateMutability": "payable",
      "type": "function",
      "payable": true
    },
    {
      "inputs": [],
      "name": "getFarmerRequests",
      "outputs": [
        {
          "components": [
            {
              "internalType": "uint256",
              "name": "requestId",
              "type": "uint256"
            },
            {
              "internalType": "uint256",
              "name": "cropID",
              "type": "uint256"
            },
            {
              "internalType": "uint256",
              "name": "quantity",
              "type": "uint256"
            },
            {
              "internalType": "address",
              "name": "buyer",
              "type": "address"
            },
            {
              "internalType": "address",
              "name": "farmer",
              "type": "address"
            },
            {
              "internalType": "uint256",
              "name": "price",
              "type": "uint256"
            },
            {
              "internalType": "enum FarmerPortal.RequestStatus",
              "name": "status",
              "type": "uint8"
            },
            {
              "internalType": "string",
              "name": "message",
              "type": "string"
            },
            {
              "internalType": "uint256",
              "name": "timestamp",
              "type": "uint256"
            }
          ],
          "internalType": "struct FarmerPortal.PurchaseRequest[]",
          "name": "",
          "type": "tuple[]"
        }
      ],
      "stateMutability": "view",
      "type": "function",
      "constant": true
    },
    {
      "inputs": [],
      "name": "getBuyerRequests",
      "outputs": [
        {
          "components": [
            {
              "internalType": "uint256",
              "name": "requestId",
              "type": "uint256"
            },
            {
              "internalType": "uint256",
              "name": "cropID",
              "type": "uint256"
            },
            {
              "internalType": "uint256",
              "name": "quantity",
              "type": "uint256"
            },
            {
              "internalType": "address",
              "name": "buyer",
              "type": "address"
            },
            {
              "internalType": "address",
              "name": "farmer",
              "type": "address"
            },
            {
              "internalType": "uint256",
              "name": "price",
              "type": "uint256"
            },
            {
              "internalType": "enum FarmerPortal.RequestStatus",
              "name": "status",
              "type": "uint8"
            },
            {
              "internalType": "string",
              "name": "message",
              "type": "string"
            },
            {
              "internalType": "uint256",
              "name": "timestamp",
              "type": "uint256"
            }
          ],
          "internalType": "struct FarmerPortal.PurchaseRequest[]",
          "name": "",
          "type": "tuple[]"
        }
      ],
      "stateMutability": "view",
      "type": "function",
      "constant": true
    },
    {
      "inputs": [],
      "name": "getPendingDeliveries",
      "outputs": [
        {
          "components": [
            {
              "internalType": "uint256",
              "name": "cropID",
              "type": "uint256"
            },
            {
              "internalType": "uint256",
              "name": "quantity",
              "type": "uint256"
            },
            {
              "internalType": "address",
              "name": "buyer",
              "type": "address"
            },
            {
              "internalType": "address",
              "name": "farmer",
              "type": "address"
            },
            {
              "internalType": "uint256",
              "name": "amountHeld",
              "type": "uint256"
            },
            {
              "internalType": "bool",
              "name": "delivered",
              "type": "bool"
            }
          ],
          "internalType": "struct FarmerPortal.Purchase[]",
          "name": "",
          "type": "tuple[]"
        }
      ],
      "stateMutability": "view",
      "type": "function",
      "constant": true
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "cropID",
          "type": "uint256"
        }
      ],
      "name": "confirmDelivery",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    }
  ];

function FarmerDashboard({ account }) {
    const [localAccount, setLocalAccount] = useState(account || "");
    const [contract, setContract] = useState(null);
    const [web3, setWeb3] = useState(null);
    const [crops, setCrops] = useState([]);
    const [orders, setOrders] = useState([]);
    const [purchaseRequests, setPurchaseRequests] = useState([]);
    const [hasNewRequests, setHasNewRequests] = useState(false);
    const [cropName, setCropName] = useState("");
    const [price, setPrice] = useState("");
    const [quantity, setQuantity] = useState("");
    const [cropID, setCropID] = useState("");
    const [deliveryDate, setDeliveryDate] = useState("");
    const [cropImage, setCropImage] = useState(null);
    const [cropImagePreview, setCropImagePreview] = useState(null);
    const [uploadingImage, setUploadingImage] = useState(false);
    const [imageCID, setImageCID] = useState("");
    const [showAddDialog, setShowAddDialog] = useState(false);
    const [loading, setLoading] = useState(true);
    const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
    const [tabValue, setTabValue] = useState(0);
    const [farmerName, setFarmerName] = useState("");
    const [profileImageUrl, setProfileImageUrl] = useState("");
    const { theme } = useTheme();

    const navigate = useNavigate();

    useEffect(() => {
        const init = async () => {
            await initializeContract();
        };
        init();

        // Listen for account changes
        if (window.ethereum) {
            window.ethereum.on('accountsChanged', (accounts) => {
                setLocalAccount(accounts[0]);
                // Re-initialize with new account
                initializeContract();
            });
        }
    }, []);

    // Refresh data when contract changes
    useEffect(() => {
        if (contract && localAccount) {
            fetchListings();
            fetchPurchaseRequests();
        }
    }, [contract, localAccount]);

    useEffect(() => {
        if (account) {
            loadFarmerProfile();
        }
    }, [account]);

    const initializeContract = async () => {
        setLoading(true);
        try {
            // Check if web3 is injected by MetaMask
            if (!window.ethereum) {
                throw new Error("Please install MetaMask to use this app.");
            }

            // Initialize web3
            const web3Instance = new Web3(window.ethereum);
            setWeb3(web3Instance);

            // Request account access
            const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
            if (!accounts || accounts.length === 0) {
                throw new Error("No accounts found. Please check MetaMask.");
            }
            
            // Set local account
            const account = accounts[0];
            setLocalAccount(account);
            console.log("Connected account:", account);

            // Create contract instance
            const contractInstance = new web3Instance.eth.Contract(
                CONTRACT_ABI,
                CONTRACT_ADDRESS
            );
            
            if (!contractInstance || !contractInstance.methods) {
                throw new Error("Failed to initialize contract.");
            }
            
            // Log available methods for debugging
            console.log("Contract methods:", Object.keys(contractInstance.methods));
            setContract(contractInstance);
            
            // Fetch data once contract is initialized
            await fetchUserProfile(contractInstance, account);
            await fetchListings();
            await fetchPurchaseRequests();
            
            // Debug contract state
            await debugContractState();
            
            console.log("Contract initialized successfully");
            
            return contractInstance;
        } catch (error) {
            console.error("Error initializing contract:", error);
            setSnackbar({
                open: true,
                message: `Error initializing: ${error.message}`,
                severity: 'error'
            });
            return null;
        } finally {
            setLoading(false);
        }
    };

    const loadFarmerProfile = async () => {
        try {
            const displayName = await getUserDisplayName(account);
            setFarmerName(displayName);
            
            // Attempt to get the profile image
            const profileImage = await getProfileImageUrl(account);
            if (profileImage) {
                setProfileImageUrl(profileImage);
            }
        } catch (error) {
            console.error("Error loading farmer profile:", error);
        }
    };

    // Function to fetch user profile data from contract
    const fetchUserProfile = async (contractInstance, userAddress) => {
        try {
            if (!contractInstance) contractInstance = contract;
            if (!userAddress) userAddress = localAccount;
            
            const profile = await contractInstance.methods.getUserProfile(userAddress).call();
            console.log("User profile data:", profile);
            
            // Profile returns [name, profileImageCID, location, contact, role]
            if (profile && profile.length >= 2) {
                const [name, profileImageCID] = profile;
                setFarmerName(name || "Farmer");
                
                if (profileImageCID) {
                    const imageUrl = getIPFSGatewayURL(profileImageCID);
                    setProfileImageUrl(imageUrl);
                }
            }
        } catch (error) {
            console.error("Error fetching user profile:", error);
        }
    };

    const 
    fetchListings = async () => {
        try {
            if (!contract || !contract.methods) {
                console.error("Contract not initialized in fetchListings");
                return;
            }
            
            console.log("Fetching listings using contract methods:", Object.keys(contract.methods));
            const listings = await contract.methods.getMyListings().call({from: localAccount});
            console.log("Raw listings from contract:", listings);
            
            const enrichedListings = await Promise.all(listings.map(async (listing) => {
                // Convert price from wei to ether
                const priceInEth = web3 ? web3.utils.fromWei(listing.price, 'ether') : '0';
                
                // Get the IPFS gateway URL for the image if available
                const imageUrl = listing.imageCID 
                    ? getIPFSGatewayURL(listing.imageCID) 
                    : null;

                return {
                    ...listing,
                    priceInEth,
                    imageUrl
                };
            }));

            console.log("Enriched listings:", enrichedListings);
            setCrops(enrichedListings);
        } catch (error) {
            console.error("Error fetching listings:", error);
            setSnackbar({
                open: true,
                message: "Error fetching listings. Please try again.",
                severity: 'error'
            });
        }
    };

    const fetchOrdersForFarmer = async (contractInstance) => {
        try {
            // This would need to be implemented in your contract
            // For now, we'll leave it empty as a placeholder
            // setOrders(await contractInstance.getOrdersForFarmer());
        } catch (error) {
            console.error("Error fetching orders:", error);
        }
    };

    // New function to fetch purchase requests
    const fetchPurchaseRequests = async (contractInstance) => {
        try {
            if (!contractInstance) contractInstance = contract;
            console.log("Fetching purchase requests...");
            console.log("Contract instance:", contractInstance);
            
            // Log the ABI function to debug
            console.log("getFarmerRequests function:", 
                CONTRACT_ABI.find(item => item.name === "getFarmerRequests"));
            
            const requests = await contractInstance.methods.getFarmerRequests().call({from: localAccount});
            console.log("Raw purchase requests:", requests);
            
            // Get raw array values for better debugging
            if (requests && requests.length > 0) {
                // Log raw array values at numeric indexes to see actual structure
                console.log("Request as array:", Array.from({length: 10}, (_, i) => requests[0][i]));
                
                console.log("First request object keys:", Object.keys(requests[0]));
                requests.forEach((req, index) => {
                    console.log(`Request ${index}:`, {
                        requestId: req.requestId ? req.requestId.toString() : 'undefined',
                        cropID: req.cropID ? req.cropID.toString() : 'undefined',
                        quantity: req.quantity ? req.quantity.toString() : 'undefined',
                        price: req.price ? req.price.toString() : 'undefined',
                        status: req.status !== undefined ? req.status.toString() : 'undefined',
                        buyer: req.buyer || 'undefined',
                        farmer: req.farmer || 'undefined',
                        message: req.message || 'undefined'
                    });
                });
            }
            
            // Enrich requests with buyer names
            const enrichedRequests = await Promise.all(requests.map(async (request) => {
                let cropName = "Unknown";
                
                // Find crop in the crops list to get the name
                for (const crop of crops) {
                    if (crop && crop.cropID && request && request.cropID && 
                        crop.cropID.toString() === request.cropID.toString()) {
                        cropName = crop.cropName;
                        break;
                    }
                }
                
                const buyerName = await getBuyerName(request.buyer);
                
                // Convert status number to string - handle if status is undefined
                const statusMap = ["Pending", "Accepted", "Rejected", "Completed"];
                let statusText = "Unknown";
                if (request && request.status !== undefined) {
                    statusText = statusMap[Number(request.status)] || "Unknown";
                }
                
                // Calculate total price using Web3.js (not ethers.js)
                const totalPrice = request && request.price && request.quantity
                    ? web3.utils.toBN(request.price).mul(web3.utils.toBN(request.quantity)).toString()
                    : '0';
                
                const enrichedRequest = {
                    ...request,
                    cropName,
                    buyerName,
                    statusText,
                    totalPrice
                };
                
                console.log("Enriched request:", enrichedRequest);
                return enrichedRequest;
            }));
            
            // Check if there are any new pending requests - safely check if status exists
            const hasPending = enrichedRequests.some(req => 
                (req && req.status && req.status.toString() === "0") || 
                (req && req.statusText === "Pending")
            );
            setHasNewRequests(hasPending);
            
            console.log("Final purchase requests:", enrichedRequests);
            setPurchaseRequests(enrichedRequests);
        } catch (error) {
            console.error("Error fetching purchase requests:", error);
            setSnackbar({
                open: true,
                message: "Error fetching purchase requests. Please try again.",
                severity: 'error'
            });
        }
    };

    // Function to get buyer's display name
    const getBuyerName = async (buyerAddress) => {
        try {
            return await getUserDisplayName(buyerAddress);
        } catch (error) {
            console.error("Error getting buyer name:", error);
            return buyerAddress.substring(0, 6) + '...' + buyerAddress.substring(buyerAddress.length - 4);
        }
    };

    const handleImageChange = (event) => {
        const file = event.target.files[0];
        if (file) {
            setCropImage(file);
            
            // Create a preview
            const reader = new FileReader();
            reader.onloadend = () => {
                setCropImagePreview(reader.result);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleImageUpload = async () => {
        if (!cropImage) {
            setSnackbar({
                open: true,
                message: "Please select an image to upload.",
                severity: 'warning'
            });
            return;
        }

        setUploadingImage(true);
        try {
            const cid = await uploadImageToPinata(cropImage);
            setImageCID(cid);
            setSnackbar({
                open: true,
                message: "Image uploaded successfully!",
                severity: 'success'
            });
        } catch (error) {
            console.error("Error uploading image:", error);
            setSnackbar({
                open: true,
                message: "Error uploading image. Please try again.",
                severity: 'error'
            });
        } finally {
            setUploadingImage(false);
        }
    };

    const addListing = async () => {
        if (!cropName || !price || !quantity || !cropID || !deliveryDate) {
            setSnackbar({
                open: true,
                message: "Please fill in all fields",
                severity: 'warning'
            });
            return;
        }

        setLoading(true);
        try {
            // Convert price to wei
            const priceInWei = web3.utils.toWei(price, 'ether');

            // Add the listing with image CID if available
            await contract.methods.addListing(
                cropName,
                priceInWei,
                cropID,
                quantity,
                deliveryDate,
                imageCID || "" // Use empty string if no image uploaded
            ).send({
                from: localAccount
            });

            setSnackbar({
                open: true,
                message: "Crop listing added successfully!",
                severity: 'success'
            });

            // Reset form and close dialog
            resetForm();
            setShowAddDialog(false);

            // Refresh listings
            await fetchListings();
        } catch (error) {
            console.error("Error adding listing:", error);
            setSnackbar({
                open: true,
                message: "Error adding listing. Please try again.",
                severity: 'error'
            });
        } finally {
            setLoading(false);
        }
    };

    const confirmDelivery = async (cropID) => {
        try {
            setLoading(true);
            const tx = await contract.confirmDelivery(cropID);
            await tx.wait();
            
            setSnackbar({
                open: true,
                message: "Delivery confirmed successfully!",
                severity: 'success'
            });
            
            // Refresh orders
            await fetchOrdersForFarmer();
        } catch (error) {
            console.error("Error confirming delivery:", error);
            setSnackbar({
                open: true,
                message: `Error confirming delivery: ${error.message}`,
                severity: 'error'
            });
        } finally {
            setLoading(false);
        }
    };

    // New function to respond to purchase requests
    const respondToPurchaseRequest = async (requestId, accept) => {
        try {
            setLoading(true);
            console.log("Responding to purchase request", { requestId, accept });
            
            // Debug contract state before attempting to respond
            await debugContractState(requestId);
            
            // Check if contract is initialized
            if (!contract) {
                console.error("Contract not initialized");
                setSnackbar({
                    open: true,
                    message: "Contract not initialized. Please refresh the page and try again.",
                    severity: 'error'
                });
                return;
            }
            
            // Check if respondToPurchaseRequest function exists on contract
            if (!contract.methods || !contract.methods.respondToPurchaseRequest) {
                console.error("respondToPurchaseRequest function not found on contract", contract);
                setSnackbar({
                    open: true,
                    message: "Contract method not found. Please refresh the page and try again.",
                    severity: 'error'
                });
                return;
            }
            
            console.log("Sending transaction with params:", requestId, accept);
            const tx = await contract.methods.respondToPurchaseRequest(requestId, accept).send({
                from: localAccount
            });
            console.log("Transaction sent:", tx);
            
            setSnackbar({
                open: true,
                message: accept ? "Purchase request accepted!" : "Purchase request rejected.",
                severity: accept ? 'success' : 'info'
            });
            
            // Refresh purchase requests
            await fetchPurchaseRequests();
        } catch (error) {
            console.error("Error responding to purchase request:", error);
            setSnackbar({
                open: true,
                message: `Error responding to purchase request: ${error.message}`,
                severity: 'error'
            });
        } finally {
            setLoading(false);
        }
    };
    
    // Debug function to check contract state
    const debugContractState = async (requestId) => {
        try {
            console.log("Debugging contract state for requestId:", requestId);
            
            // Get all requests again to verify what's available
            const requests = await contract.methods.getFarmerRequests().call({from: localAccount});
            console.log("All requests at debug time:", requests);
            
            // If we have the specific request ID, check if it exists in the array
            if (requestId) {
                const matchingRequest = requests.find(req => 
                    req && req.requestId && req.requestId.toString() === requestId.toString()
                );
                console.log("Matching request found:", matchingRequest || "No matching request found");
            }
        } catch (error) {
            console.error("Error in debugContractState:", error);
        }
    };

    const resetForm = () => {
        setCropName("");
        setPrice("");
        setQuantity("");
        setCropID("");
        setDeliveryDate("");
        setCropImage(null);
        setCropImagePreview(null);
        setImageCID("");
    };

    const handleOpenAddDialog = () => {
        resetForm();
        setShowAddDialog(true);
    };

    const handleCloseAddDialog = () => {
        setShowAddDialog(false);
    };

    const handleCloseSnackbar = () => {
        setSnackbar({ ...snackbar, open: false });
    };

    const handleTabChange = (event, newValue) => {
        setTabValue(newValue);
        if (newValue === 1) {
            // If switching to the purchase requests tab, clear the notification indicator
            setHasNewRequests(false);
        }
    };

    // Helper function to safely format ETH price
    const formatEthPrice = (weiPrice) => {
        try {
            if (!web3 || !weiPrice) return '0';
            return web3.utils.fromWei(weiPrice.toString(), 'ether');
        } catch (error) {
            console.error("Error formatting ETH price:", error, weiPrice);
            return "0";
        }
    };

    // Helper function to get crop image URL
    const getCropImageUrl = (crop) => {
        if (crop && crop.imageCID) {
            return getIPFSGatewayURL(crop.imageCID);
        }
        // Return a default image if no CID is available
        return 'https://via.placeholder.com/300x200?text=No+Image';
    };

    return (
        <Box className="full-page">
            <AppBar position="static" className="glass sticky top-0 z-50" 
                sx={{ 
                    backdropFilter: 'blur(15px)', 
                    borderBottom: '1px solid', 
                    borderColor: 'border',
                    boxShadow: 'none' 
                }}
            >
                <Toolbar className="px-4">
                    <motion.div 
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.5, type: "spring", stiffness: 100 }}
                        className="text-primary flex items-center"
                    >
                        <AgricultureIcon className="mr-2 animate-float" />
                        <Typography 
                            variant="h6" 
                            component="div" 
                            className="font-medium hidden sm:block"
                        >
                            <motion.div
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                className="bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent inline-block"
                            >
                                Farm Assure
                            </motion.div>
                    </Typography>
                    </motion.div>
                    
                    <Box sx={{ flexGrow: 1 }} />
                    
                    <Box className="flex items-center gap-2">
                        <motion.div
                            initial={{ opacity: 0, scale: 0.9 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ 
                                type: "spring", 
                                stiffness: 500, 
                                damping: 30, 
                                delay: 0.3 
                            }}
                        >
                        <Chip
                                avatar={
                                    <Avatar 
                                        src={profileImageUrl}
                                        className="border-2 border-primary/30"
                                    >
                                        <PersonIcon className="text-primary-foreground" />
                                    </Avatar>
                                }
                                label={farmerName || (account ? `${account.substring(0, 6)}...${account.substring(account.length - 4)}` : 'Not Connected')}
                            variant="outlined"
                                className="bg-background/50 backdrop-blur shadow-sm hover:shadow-md transition-all duration-300 border border-border cursor-pointer"
                                sx={{ 
                                    '& .MuiChip-label': {
                                        display: 'flex',
                                        whiteSpace: 'nowrap',
                                        overflow: 'hidden',
                                        textOverflow: 'ellipsis',
                                        maxWidth: {xs: '80px', sm: '150px'},
                                        color: 'text.primary'
                                    }
                                }}
                            onClick={() => navigate("/profile")}
                        />
                        </motion.div>
                        
                        <motion.div
                            initial={{ opacity: 0, scale: 0.9 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ 
                                type: "spring", 
                                stiffness: 500, 
                                damping: 30, 
                                delay: 0.4 
                            }}
                            className="flex items-center gap-2"
                        >
                            <ThemeToggle />
                        </motion.div>

                        <motion.div
                            initial={{ opacity: 0, scale: 0.9 }}
                            animate={{ opacity: 1, scale: 1 }}
                            whileHover={{ scale: 1.1, rotate: 5 }}
                            whileTap={{ scale: 0.9 }}
                            transition={{ 
                                type: "spring", 
                                stiffness: 500, 
                                damping: 30, 
                                delay: 0.5 
                            }}
                        >
                            <IconButton 
                                color="inherit" 
                                onClick={() => navigate("/")}
                                className="hover:bg-background/80 text-foreground"
                                size="large"
                            >
                                <LogoutIcon className="text-foreground" />
                        </IconButton>
                        </motion.div>
                    </Box>
                </Toolbar>
            </AppBar>

            <Container maxWidth="lg" className="flex-1 py-6 px-4 app-container">
                <Box className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
                    <Typography variant="h4" component="h1" className="font-bold text-foreground">
                        Welcome, {farmerName || 'Farmer'}
                    </Typography>
                    <motion.div
                        whileHover={{ scale: 1.03 }}
                        whileTap={{ scale: 0.97 }}
                    >
                    <Button
                        variant="contained"
                            className="bg-primary text-primary-foreground hover:bg-primary/90 transition-all"
                        startIcon={<AddIcon />}
                        onClick={handleOpenAddDialog}
                            size="large"
                    >
                        Add New Crop
                    </Button>
                    </motion.div>
                </Box>

                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.3, type: "spring", stiffness: 100 }}
                    className="mb-6"
                >
                    <Paper 
                        elevation={0} 
                        className="glass rounded-lg overflow-hidden border border-border/50"
                    >
                    <Tabs 
                        value={tabValue} 
                        onChange={handleTabChange} 
                        centered
                        indicatorColor="primary"
                        textColor="primary"
                            className="font-medium"
                            variant="fullWidth"
                            sx={{
                                '& .MuiTabs-indicator': {
                                    height: '3px',
                                    borderRadius: '3px 3px 0 0'
                                },
                                '& .MuiTab-root': {
                                    transition: 'all 0.3s',
                                    fontWeight: 500,
                                    textTransform: 'none',
                                    py: 2,
                                    px: {xs: 1, sm: 3},
                                    fontSize: {xs: '0.875rem', sm: '1rem'}
                                }
                            }}
                        >
                            <Tab 
                                label="My Listings" 
                                icon={<InventoryIcon className="text-primary" />}
                                iconPosition="start"
                                className="transition-all duration-300 hover:bg-background/50"
                            />
                        <Tab 
                            label="Purchase Requests" 
                                icon={hasNewRequests ? 
                                    <Badge color="error" variant="dot"><NotificationsIcon className="text-primary" /></Badge> : 
                                    <NotificationsIcon className="text-primary" />
                                }
                                iconPosition="start"
                                className="transition-all duration-300 hover:bg-background/50"
                            />
                            <Tab 
                                label="Orders & Deliveries"
                                icon={<LocalShippingIcon className="text-primary" />}
                                iconPosition="start" 
                                className="transition-all duration-300 hover:bg-background/50"
                            />
                    </Tabs>
                </Paper>
                </motion.div>

                {tabValue === 0 && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 0.5 }}
                    >
                    <Grid container spacing={3}>
                        {loading ? (
                                <Grid item xs={12}>
                                    <Box className="flex justify-center items-center py-12">
                                        <motion.div
                                            animate={{ rotate: 360 }}
                                            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                                        >
                                            <CircularProgress className="text-primary" />
                                        </motion.div>
                                    </Box>
                            </Grid>
                        ) : crops.length > 0 ? (
                            crops.map((crop, index) => (
                                <Grid item xs={12} sm={6} md={4} key={index}>
                                        <motion.div
                                            initial={{ opacity: 0, y: 20 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            transition={{ 
                                                duration: 0.5, 
                                                delay: 0.1 * index,
                                                type: "spring",
                                                stiffness: 100,
                                                damping: 15
                                            }}
                                            whileHover={{ y: -8 }}
                                            className="h-full"
                                        >
                                            <Card 
                                                elevation={0} 
                                                className="h-full flex flex-col overflow-hidden transition-all duration-500 hover:shadow-xl bg-background/40 backdrop-blur-md border border-border rounded-lg"
                                            >
                                        <Box 
                                            sx={{ 
                                                        height: 220, 
                                                        position: 'relative',
                                                        overflow: 'hidden'
                                                    }}
                                                >
                                                    <motion.div
                                                        whileHover={{ scale: 1.05 }}
                                                        transition={{ duration: 0.5 }}
                                                        style={{
                                                            position: 'absolute',
                                                            top: 0,
                                                            left: 0,
                                                            width: '100%',
                                                            height: '100%',
                                                backgroundImage: `url(${getCropImageUrl(crop)})`,
                                                backgroundSize: 'cover',
                                                            backgroundPosition: 'center',
                                                        }}
                                                    />
                                                    <Box
                                                        className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent"
                                                    />
                                                    <Box
                                                        className="absolute bottom-0 left-0 right-0 p-3 text-foreground"
                                                    >
                                                        <Typography className="text-lg font-bold text-shadow-sm">
                                                {crop.cropName}
                                            </Typography>
                                                        <Typography variant="caption" className="text-foreground/75">
                                                            ID: {crop.cropID.toString()}
                                            </Typography>
                                                    </Box>
                                                </Box>
                                                
                                                <CardContent sx={{ flexGrow: 1, pt: 3 }} className="stagger-animation">
                                                    <Box className="space-y-3">
                                                        <Box className="flex items-center gap-2 text-foreground">
                                                            <AttachMoneyIcon className="text-primary" fontSize="small" />
                                                            <Typography variant="body1" className="font-medium">
                                                                {crop.priceInEth || formatEthPrice(crop.price)} ETH per kg
                                            </Typography>
                                                        </Box>
                                                        
                                                        <Box className="flex items-center gap-2 text-foreground">
                                                            <InventoryIcon className="text-primary" fontSize="small" />
                                                            <Typography variant="body1" className="font-medium">
                                                                {crop.quantity.toString()} kg available
                                            </Typography>
                                                        </Box>
                                                        
                                                        <Box className="flex items-center gap-2 text-foreground">
                                                            <CalendarMonthIcon className="text-primary" fontSize="small" />
                                                            <Typography variant="body1" className="font-medium">
                                                                Delivery by {crop.deliveryDate}
                                            </Typography>
                                                        </Box>
                                                    </Box>
                                        </CardContent>
                                    </Card>
                                        </motion.div>
                                </Grid>
                        ))
                    ) : (
                            <Grid item xs={12}>
                                    <Paper elevation={0} className="p-8 text-center bg-background/50 border border-border rounded-lg">
                                        <Box className="flex flex-col items-center gap-4">
                                            <motion.div
                                                animate={{ y: [0, -10, 0] }}
                                                transition={{ duration: 2, repeat: Infinity }}
                                            >
                                                <InventoryIcon className="text-muted-foreground" sx={{ fontSize: 60 }} />
                                            </motion.div>
                                            <Typography variant="h6" className="text-foreground font-medium">
                                        No crops listed. Add your first crop!
                                    </Typography>
                                            <motion.div
                                                whileHover={{ scale: 1.05 }}
                                                whileTap={{ scale: 0.95 }}
                                            >
                                                <Button 
                                                    variant="contained"
                                                    onClick={handleOpenAddDialog}
                                                    startIcon={<AddIcon />}
                                                    className="mt-4 bg-primary text-primary-foreground hover:bg-primary/90"
                                                >
                                                    Add New Crop
                                                </Button>
                                            </motion.div>
                                        </Box>
                                </Paper>
                            </Grid>
                        )}
                    </Grid>
                    </motion.div>
                )}

                {tabValue === 1 && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5 }}
                        className="h-full"
                    >
                        <Typography variant="h5" className="font-bold text-foreground mb-6">
                            Purchase Requests
                        </Typography>
                        
                        {loading ? (
                            <Box className="flex justify-center items-center py-12">
                                <motion.div
                                    animate={{ rotate: 360 }}
                                    transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                                >
                                    <CircularProgress className="text-primary" />
                                </motion.div>
                            </Box>
                        ) : (
                            <Paper 
                                elevation={0} 
                                className="glass border border-border rounded-lg overflow-hidden"
                            >
                                <Box className="scrollable-container">
                                    <TableContainer component={Paper} elevation={0} className="bg-transparent">
                                        <Table className="table-responsive">
                                            <TableHead>
                                        <TableRow>
                                                    <TableCell className="font-bold">Request ID</TableCell>
                                                    <TableCell className="font-bold">Crop</TableCell>
                                                    <TableCell className="font-bold">Buyer</TableCell>
                                                    <TableCell className="font-bold">Quantity</TableCell>
                                                    <TableCell className="font-bold">Price</TableCell>
                                                    <TableCell className="font-bold">Status</TableCell>
                                                    <TableCell className="font-bold">Actions</TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {purchaseRequests.length > 0 ? (
                                            purchaseRequests.map((request, index) => (
                                                <TableRow key={request && request.requestId ? request.requestId.toString() : index}>
                                                    <TableCell>{request && request.requestId ? request.requestId.toString() : 'N/A'}</TableCell>
                                                            <TableCell>
                                                                <Box className="flex items-center gap-2">
                                                                    <motion.div 
                                                                        whileHover={{ scale: 1.1 }} 
                                                                        className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center text-primary"
                                                                    >
                                                                        <InventoryIcon fontSize="small" />
                                                                    </motion.div>
                                                                    <Typography>{request.cropName || 'N/A'}</Typography>
                                                                </Box>
                                                            </TableCell>
                                                    <TableCell>{request.buyerName || 'N/A'}</TableCell>
                                                    <TableCell>
                                                                <Typography className="font-medium">
                                                                    {request && request.quantity ? request.quantity.toString() : '0'} kg
                                                                </Typography>
                                                    </TableCell>
                                                    <TableCell>
                                                                <Typography className="font-medium text-primary">
                                                            {web3 && request && request.price ? web3.utils.fromWei(request.price, 'ether') : '0'} ETH per kg
                                                        </Typography>
                                                                <Typography variant="caption" className="text-muted-foreground">
                                                            Total: {web3 && request && request.quantity && request.price ? 
                                                                web3.utils.fromWei(
                                                                    web3.utils.toBN(request.price)
                                                                        .mul(web3.utils.toBN(request.quantity))
                                                                        .toString(), 
                                                                    'ether'
                                                                ) : '0'} ETH
                                                        </Typography>
                                                    </TableCell>
                                                    <TableCell>
                                                        <Chip 
                                                            label={request.statusText || 'Unknown'} 
                                                            color={
                                                                request && request.status && request.status.toString() === "0" ? "warning" : 
                                                                request && request.status && request.status.toString() === "1" ? "success" : 
                                                                request && request.status && request.status.toString() === "2" ? "error" : 
                                                                request && request.status && request.status.toString() === "3" ? "default" :
                                                                "default"
                                                            }
                                                            size="small"
                                                                    className="font-medium"
                                                        />
                                                    </TableCell>
                                                    <TableCell>
                                                        {/* Show Accept/Reject buttons for all requests that appear to be pending */}
                                                        {(request && 
                                                          ((request.status && request.status.toString() === "0") || 
                                                           (request.statusText === "Pending"))) ? (
                                                                    <Box className="flex gap-2">
                                                                        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                                                                <Button
                                                                    variant="contained"
                                                                    color="success"
                                                                    size="small"
                                                                    startIcon={<CheckCircleIcon />}
                                                                    onClick={() => respondToPurchaseRequest(request.requestId || 0, true)}
                                                                                className="font-medium"
                                                                >
                                                                    Accept
                                                                </Button>
                                                                        </motion.div>
                                                                        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                                                                <Button
                                                                    variant="contained"
                                                                    color="error"
                                                                    size="small"
                                                                    startIcon={<CancelIcon />}
                                                                    onClick={() => respondToPurchaseRequest(request.requestId || 0, false)}
                                                                                className="font-medium"
                                                                >
                                                                    Reject
                                                                </Button>
                                                                        </motion.div>
                                                            </Box>
                                                        ) : (
                                                                    <Typography variant="body2" className="text-muted-foreground">
                                                                {request && request.status && request.status.toString() === "1" ? "Accepted" :
                                                                 request && request.status && request.status.toString() === "2" ? "Rejected" :
                                                                 request && request.status && request.status.toString() === "3" ? "Completed" : 
                                                                 request && request.statusText === "Accepted" ? "Accepted" :
                                                                 request && request.statusText === "Rejected" ? "Rejected" :
                                                                 request && request.statusText === "Completed" ? "Completed" :
                                                                 "No action needed"}
                                                            </Typography>
                                                        )}
                                                    </TableCell>
                                                </TableRow>
                                            ))
                                        ) : (
                                            <TableRow>
                                                        <TableCell colSpan={7} align="center" className="py-8">
                                                            <Box className="flex flex-col items-center gap-3">
                                                                <motion.div
                                                                    animate={{ y: [0, -10, 0] }}
                                                                    transition={{ duration: 2, repeat: Infinity }}
                                                                >
                                                                    <ShoppingCartIcon className="text-muted-foreground" sx={{ fontSize: 40 }} />
                                                                </motion.div>
                                                                <Typography className="text-muted-foreground">
                                                                    No purchase requests found
                                                    </Typography>
                                                            </Box>
                                                </TableCell>
                                            </TableRow>
                                        )}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                                </Box>
                            </Paper>
                        )}
                    </motion.div>
                )}

                {tabValue === 2 && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5 }}
                        className="h-full"
                    >
                        <Box className="flex flex-col items-center justify-center py-12 gap-4">
                            <motion.div
                                animate={{ y: [0, -10, 0] }}
                                transition={{ duration: 2, repeat: Infinity }}
                            >
                                <LocalShippingIcon className="text-muted-foreground" sx={{ fontSize: 64 }} />
                            </motion.div>
                            <Typography variant="h5" className="font-bold text-foreground">
                                Orders and Deliveries
                    </Typography>
                            <Typography className="text-muted-foreground text-center max-w-lg">
                                Orders and delivery tracking will be implemented soon. You'll be able to manage your deliveries and track order statuses here.
                            </Typography>
                            <motion.div
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                                className="mt-4"
                            >
                                <Button 
                                    variant="outlined" 
                                    className="border-primary text-primary hover:bg-primary/5"
                                    startIcon={<BugReportIcon />}
                                    onClick={debugContractState}
                                >
                                    Debug Contract State
                                </Button>
                            </motion.div>
                        </Box>
                    </motion.div>
                )}
            </Container>

            <Dialog
                open={showAddDialog}
                onClose={handleCloseAddDialog}
                aria-labelledby="add-crop-dialog-title"
                aria-describedby="add-crop-dialog-description"
            >
                <Paper 
                    elevation={0} 
                    className="glass rounded-lg overflow-hidden border border-border/50"
                >
                    <DialogTitle className="flex justify-between items-center border-b border-border pb-4">
                        <Typography variant="h5" component="h2" className="font-bold text-foreground">
                            Add New Crop
                        </Typography>
                        <IconButton onClick={handleCloseAddDialog} edge="end" className="text-muted-foreground hover:text-foreground">
                            <CloseIcon />
                        </IconButton>
                    </DialogTitle>
                    <DialogContent className="mt-4">
                        <div className="stagger-animation space-y-4">
                            <Typography className="text-muted-foreground mb-4">
                        Enter the details of your crop to list it on the marketplace.
                            </Typography>
                            
                    <TextField
                        autoFocus
                        margin="dense"
                        label="Crop Name"
                        fullWidth
                        value={cropName}
                        onChange={(e) => setCropName(e.target.value)}
                                className="focus-ring"
                                InputProps={{
                                    className: "accent-border"
                                }}
                    />
                            
                    <TextField
                        margin="dense"
                        label="Price per kg (ETH)"
                        type="number"
                        fullWidth
                        value={price}
                        onChange={(e) => setPrice(e.target.value)}
                        inputProps={{ step: "0.001" }}
                                className="focus-ring"
                                InputProps={{
                                    className: "accent-border"
                                }}
                    />
                            
                    <TextField
                        margin="dense"
                        label="Quantity Available (kg)"
                        type="number"
                        fullWidth
                        value={quantity}
                        onChange={(e) => setQuantity(e.target.value)}
                                className="focus-ring"
                                InputProps={{
                                    className: "accent-border"
                                }}
                    />
                            
                    <TextField
                        margin="dense"
                        label="Crop ID"
                        type="number"
                        fullWidth
                        value={cropID}
                        onChange={(e) => setCropID(e.target.value)}
                                className="focus-ring"
                                InputProps={{
                                    className: "accent-border"
                                }}
                    />
                            
                    <TextField
                        margin="dense"
                        label="Delivery Date"
                        fullWidth
                        value={deliveryDate}
                        onChange={(e) => setDeliveryDate(e.target.value)}
                        placeholder="e.g., 15th June 2023"
                                className="focus-ring"
                                InputProps={{
                                    className: "accent-border"
                                }}
                            />
                            
                            <div className="mt-6 mb-2">
                                <Typography variant="subtitle1" gutterBottom className="font-medium">
                                    Upload Crop Image
                        </Typography>
                                
                                <Box className="mt-2 border-2 border-dashed border-border rounded-lg p-6 text-center transition-all hover:border-primary">
                        <input
                            type="file"
                            accept="image/*"
                            onChange={handleImageChange}
                            style={{ display: 'none' }}
                            id="crop-image-upload"
                        />
                                    
                                    {!cropImagePreview ? (
                                        <label htmlFor="crop-image-upload" className="cursor-pointer">
                                            <motion.div
                                                whileHover={{ scale: 1.02 }}
                                                whileTap={{ scale: 0.98 }}
                                                className="flex flex-col items-center justify-center"
                                            >
                                                <CloudUploadIcon 
                                                    className="text-muted-foreground mb-2 animate-float"
                                                    sx={{ fontSize: 60 }}
                                                />
                                                <Typography variant="body1" className="font-medium mb-1 text-foreground">
                                                    Drag and drop or click to upload
                                                </Typography>
                                                <Typography variant="caption" className="text-muted-foreground">
                                                    PNG, JPG up to 5MB
                                                </Typography>
                                            </motion.div>
                        </label>
                                    ) : (
                                        <div className="relative">
                                            <motion.div
                                                initial={{ opacity: 0, scale: 0.9 }}
                                                animate={{ opacity: 1, scale: 1 }}
                                                className="relative"
                                            >
                                                <img 
                                                    src={cropImagePreview} 
                                                    alt="Crop preview" 
                                                    className="max-h-[200px] mx-auto object-contain rounded-md"
                                                />
                                                <IconButton
                                                    className="absolute top-2 right-2 bg-background/80 text-foreground hover:bg-background shadow-md"
                                                    size="small"
                                                    onClick={() => {
                                                        setCropImage(null);
                                                        setCropImagePreview(null);
                                                        setImageCID("");
                                                    }}
                                                >
                                                    <CloseIcon fontSize="small" />
                                                </IconButton>
                                            </motion.div>
                                            
                                            {!imageCID && (
                        <Button
                            variant="contained"
                            onClick={handleImageUpload}
                            disabled={!cropImage || uploadingImage}
                                                    className="mt-4 btn-gradient"
                                                    startIcon={uploadingImage ? <CircularProgress size={20} /> : <CloudUploadIcon />}
                        >
                                                    {uploadingImage ? "Uploading..." : "Upload to IPFS"}
                        </Button>
                                            )}
                                            
                                {imageCID && (
                                                <motion.div
                                                    initial={{ opacity: 0, y: 10 }}
                                                    animate={{ opacity: 1, y: 0 }}
                                                    className="mt-2 flex items-center justify-center text-green-500 gap-1"
                                                >
                                                    <CheckCircleIcon fontSize="small" />
                                                    <Typography variant="caption" className="font-medium">
                                                        Image uploaded to IPFS successfully
                                    </Typography>
                                                </motion.div>
                                )}
                                        </div>
                        )}
                    </Box>
                            </div>
                        </div>
                </DialogContent>
                    <DialogActions className="border-t border-border p-4">
                        <Button onClick={handleCloseAddDialog} color="inherit" className="hover:bg-background-muted">
                        Cancel
                    </Button>
                        <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
                    <Button 
                        onClick={addListing} 
                                className="bg-primary text-primary-foreground hover:bg-primary/90"
                        variant="contained"
                                disabled={loading || !cropName || !price || !quantity || !cropID || !deliveryDate}
                                startIcon={loading ? <CircularProgress size={20} color="inherit" /> : <AddIcon />}
                    >
                                {loading ? "Processing..." : "Add Listing"}
                    </Button>
                        </motion.div>
                </DialogActions>
                </Paper>
            </Dialog>

            {/* Snackbar for notifications */}
            <Snackbar 
                open={snackbar.open} 
                autoHideDuration={6000} 
                onClose={handleCloseSnackbar}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                TransitionComponent={React.forwardRef((props, ref) => {
                    return <motion.div
                        ref={ref}
                        initial={{ opacity: 0, y: 50 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 50 }}
                        transition={{ type: "spring", stiffness: 500, damping: 30 }}
                        {...props}
                    />;
                })}
            >
                <Alert 
                    onClose={handleCloseSnackbar} 
                    severity={snackbar.severity} 
                    variant="filled"
                    sx={{ width: '100%' }}
                    className="shadow-lg"
                >
                    {snackbar.message}
                </Alert>
            </Snackbar>
        </Box>
    );
}

export default FarmerDashboard;
