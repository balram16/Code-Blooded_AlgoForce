import React, { useState, useEffect } from "react";
import { BrowserProvider, Contract } from "ethers";
import Web3Modal from "web3modal";
import { useNavigate } from "react-router-dom";
import { 
  Box, 
  Button, 
  Container, 
  Typography, 
  Paper, 
  FormControl, 
  RadioGroup, 
  Radio, 
  FormControlLabel,
  AppBar,
  Toolbar,
  Card,
  CardContent,
  Grid,
  CircularProgress
} from '@mui/material';
import { AccountBalanceWallet, Agriculture, ShoppingCart } from '@mui/icons-material';
import { motion } from "framer-motion";
import { useTheme } from "../components/theme-provider";
import { ThemeToggle } from "../components/theme-toggle";

const CONTRACT_ADDRESS = "0x0e5951144d4d18F8771e3F15BFC3aB4e2ba2d8A2";

const contractABI = [
  {
    "anonymous": false,
    "inputs": [
      { "indexed": true, "internalType": "address", "name": "user", "type": "address" },
      { "indexed": false, "internalType": "enum FarmerPortal.UserRole", "name": "role", "type": "uint8" }
    ],
    "name": "UserRegistered",
    "type": "event"
  },
  {
    "inputs": [{ "internalType": "address", "name": "_user", "type": "address" }],
    "name": "getUserRole",
    "outputs": [{ "internalType": "enum FarmerPortal.UserRole", "name": "", "type": "uint8" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{ "internalType": "uint8", "name": "role", "type": "uint8" }],
    "name": "registerUser",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  }
];

function LoginPage({ onLogin }) {
  const [account, setAccount] = useState(null);
  const [role, setRole] = useState(null);
  const [registeredRole, setRegisteredRole] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const { theme } = useTheme();

  useEffect(() => {
    checkWalletConnection();
  }, []);

  const connectWallet = async () => {
    try {
      setLoading(true);
      setError(null);
      const web3Modal = new Web3Modal();
      const connection = await web3Modal.connect();
      const provider = new BrowserProvider(connection);
      const signer = await provider.getSigner();
      const address = await signer.getAddress();
      setAccount(address);
      fetchUserRole(address, provider);
    } catch (error) {
      console.error("Wallet connection failed:", error);
      setError("Failed to connect wallet. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const checkWalletConnection = async () => {
    try {
    if (window.ethereum) {
      const provider = new BrowserProvider(window.ethereum);
      const accounts = await provider.send("eth_accounts", []);
      if (accounts.length > 0) {
        setAccount(accounts[0]);
        fetchUserRole(accounts[0], provider);
      }
      }
    } catch (error) {
      console.error("Error checking wallet connection:", error);
    }
  };
  
  const fetchUserRole = async (userAddress, provider) => {
    try {
      setLoading(true);
      setError(null);
      const contract = new Contract(CONTRACT_ADDRESS, contractABI, provider);
      const role = await contract.getUserRole(userAddress);
      const roleString = role.toString();
      console.log("Fetched user role:", roleString);
      
      // Only set registered role if it's not "0" (unregistered)
      if (roleString !== "0") {
      setRegisteredRole(roleString); 

        // Pass account and role to parent component
        if (onLogin) {
          onLogin(userAddress, roleString);
        }
 
      if (roleString === "1") {
          navigate("/farmer-dashboard"); 
      } else if (roleString === "2") {
          navigate("/buyer-dashboard"); 
        }
      } else {
        console.log("User is not registered yet");
        setRegisteredRole(null);
      }
    } catch (error) {
      console.error("Error fetching user role:", error);
      setError("Error fetching user role. Please try again.");
    } finally {
      setLoading(false);
    }
  };
  
  const registerRole = async () => {
    if (!account || role === null) return;
    try {
      setLoading(true);
      setError(null);
      const provider = new BrowserProvider(window.ethereum);
      const signer = await provider.getSigner();
      const contract = new Contract(CONTRACT_ADDRESS, contractABI, signer);

      console.log("Registering role:", role);
      const tx = await contract.registerUser(role);
      console.log("Transaction sent:", tx);
      await tx.wait();
      console.log("Transaction confirmed");

      // Pass account and role to parent component
      if (onLogin) {
        onLogin(account, role.toString());
      }

      setRegisteredRole(role.toString());
      
      if (role === 1) {
        navigate("/farmer-dashboard");
      } else if (role === 2) {
        navigate("/buyer-dashboard");
      }
    } catch (error) {
      console.error("Error registering role:", error);
      setError("Error registering role. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box sx={{ 
      minHeight: '100vh', 
      background: theme === 'dark' 
        ? 'linear-gradient(135deg, hsl(var(--background)) 0%, hsl(var(--card)) 100%)' 
        : 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--secondary)) 100%)',
      display: 'flex',
      flexDirection: 'column'
    }}>
      <AppBar position="static" color="transparent" elevation={0} className="glass">
        <Toolbar>
          <Typography variant="h5" component="div" sx={{ flexGrow: 1, fontWeight: 'bold', color: 'white' }}>
            Farm Assure
          </Typography>
          <ThemeToggle />
        </Toolbar>
      </AppBar>

      <Container maxWidth="md" sx={{ mt: 8, mb: 4 }}>
        <Grid container spacing={4}>
          <Grid item xs={12} md={6}>
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
            >
              <Box sx={{ color: 'white', pr: { md: 4 }, mb: { xs: 4, md: 0 } }}>
                <Typography variant="h3" component="h1" gutterBottom fontWeight="bold">
                  Blockchain-Powered Agriculture Marketplace
                </Typography>
                <Typography variant="h6" paragraph>
                  Connect farmers directly with buyers, ensuring transparency, fair prices, and secure transactions.
                </Typography>
              </Box>
            </motion.div>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Paper elevation={0} sx={{ p: 4, borderRadius: 'var(--radius)' }} className="glass">
                <Typography variant="h5" component="h2" gutterBottom align="center" fontWeight="bold" className="text-foreground">
                  {account ? "Welcome to Farm Assure" : "Connect Your Wallet"}
                </Typography>
                
                {error && (
                  <Typography color="error" sx={{ mb: 2, textAlign: 'center' }}>
                    {error}
                  </Typography>
                )}

                {!account ? (
                  <Box sx={{ textAlign: 'center', mt: 3 }}>
                    <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      <Button 
                        variant="contained" 
                        color="primary" 
                        size="large"
                        startIcon={<AccountBalanceWallet />}
                        onClick={connectWallet}
                        disabled={loading}
                        sx={{ py: 1.5, px: 4 }}
                        className="bg-primary text-primary-foreground hover:bg-primary/90"
                      >
                        {loading ? <CircularProgress size={24} color="inherit" /> : "Connect Wallet"}
                      </Button>
                    </motion.div>
                  </Box>
                ) : (
                  <Box>
                    <Typography variant="body1" sx={{ mb: 2, wordBreak: 'break-all' }}>
                      Connected: {account}
                    </Typography>
                    
                    {registeredRole ? (
                      <Typography variant="body1" sx={{ mt: 2, textAlign: 'center' }}>
                        You are registered as: <strong>{registeredRole === "1" ? "Farmer" : "Buyer"}</strong>
                      </Typography>
                    ) : (
                      <>
                        <Typography variant="h6" sx={{ mt: 3, mb: 2 }}>
                          Select your role:
                        </Typography>
                        
                        <FormControl component="fieldset" fullWidth sx={{ mb: 3 }}>
                          <RadioGroup
                            value={role}
                            onChange={(e) => setRole(parseInt(e.target.value))}
                            sx={{ width: '100%' }}
                          >
                            <Grid container spacing={2} sx={{ width: '100%', margin: 0 }}>
                              <Grid item xs={6} sx={{ paddingTop: '0 !important' }}>
                                <motion.div 
                                  whileHover={{ y: -5 }} 
                                  transition={{ type: "spring", stiffness: 400 }}
                                  style={{ height: '100%' }}
                                >
                                  <Card 
                                    variant={role === 1 ? "outlined" : "elevation"} 
                                    sx={{ 
                                      cursor: 'pointer',
                                      border: role === 1 ? '2px solid hsl(var(--primary))' : '1px solid hsl(var(--border))',
                                      transition: 'all 0.3s ease',
                                      height: '100%',
                                      display: 'flex',
                                      flexDirection: 'column',
                                      justifyContent: 'center',
                                      alignItems: 'center',
                                      bgcolor: role === 1 ? 'primary.main/5' : 'background.paper',
                                      padding: 2
                                    }}
                                    onClick={() => setRole(1)}
                                    className={`hover-lift ${role === 1 ? 'glass' : ''}`}
                                  >
                                    <CardContent sx={{ 
                                      textAlign: 'center', 
                                      py: 3, 
                                      display: 'flex', 
                                      flexDirection: 'column', 
                                      alignItems: 'center',
                                      justifyContent: 'center',
                                      height: '100%',
                                      width: '100%'
                                    }}>
                                      <Agriculture fontSize="large" color="primary" sx={{ mb: 1 }} />
                                      <FormControlLabel
                                        value="1"
                                        control={
                                          <Radio 
                                            checked={role === 1}
                                            onChange={() => {}}
                                            onClick={(e) => e.stopPropagation()}
                                          />
                                        }
                                        label="Farmer"
                                        sx={{ mt: 1 }}
                                      />
                                    </CardContent>
                                  </Card>
                                </motion.div>
                              </Grid>
                              <Grid item xs={6} sx={{ paddingTop: '0 !important' }}>
                                <motion.div 
                                  whileHover={{ y: -5 }} 
                                  transition={{ type: "spring", stiffness: 400 }}
                                  style={{ height: '100%' }}
                                >
                                  <Card 
                                    variant={role === 2 ? "outlined" : "elevation"} 
                                    sx={{ 
                                      cursor: 'pointer',
                                      border: role === 2 ? '2px solid hsl(var(--primary))' : '1px solid hsl(var(--border))',
                                      transition: 'all 0.3s ease',
                                      height: '100%',
                                      display: 'flex',
                                      flexDirection: 'column',
                                      justifyContent: 'center',
                                      alignItems: 'center',
                                      bgcolor: role === 2 ? 'primary.main/5' : 'background.paper',
                                      padding: 2
                                    }}
                                    onClick={() => setRole(2)}
                                    className={`hover-lift ${role === 2 ? 'glass' : ''}`}
                                  >
                                    <CardContent sx={{ 
                                      textAlign: 'center', 
                                      py: 3, 
                                      display: 'flex', 
                                      flexDirection: 'column', 
                                      alignItems: 'center',
                                      justifyContent: 'center',
                                      height: '100%',
                                      width: '100%'
                                    }}>
                                      <ShoppingCart fontSize="large" color="primary" sx={{ mb: 1 }} />
                                      <FormControlLabel
                                        value="2"
                                        control={
                                          <Radio 
                                            checked={role === 2}
                                            onChange={() => {}}
                                            onClick={(e) => e.stopPropagation()}
                                          />
                                        }
                                        label="Buyer"
                                        sx={{ mt: 1 }}
                                      />
                                    </CardContent>
                                  </Card>
                                </motion.div>
                              </Grid>
                            </Grid>
                          </RadioGroup>
                        </FormControl>
                        
                        <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                          <Button
                            variant="contained"
                            color="primary"
                            fullWidth
                            size="large"
                            onClick={registerRole}
                            disabled={role === null || loading}
                            sx={{ py: 1.5 }}
                            className="bg-primary text-primary-foreground hover:bg-primary/90"
                          >
                            {loading ? <CircularProgress size={24} color="inherit" /> : "Register Role"}
                          </Button>
                        </motion.div>
                      </>
                    )}
                  </Box>
                )}
              </Paper>
            </motion.div>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
}

export default LoginPage;
