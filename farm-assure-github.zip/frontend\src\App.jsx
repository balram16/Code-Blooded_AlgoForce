import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { ThemeProvider as MuiThemeProvider, createTheme, CssBaseline, useMediaQuery } from '@mui/material';
import ThemeProvider from "./components/theme-provider";
import LoginPage from "./pages/LoginPage.jsx";
import FarmerDashboard from "./pages/FarmerDashboard.jsx"; // ✅ Import FarmerDashboard
import BuyerDashboard from "./pages/BuyerDashboard.jsx";   // ✅ Import BuyerDashboard
import ProfilePage from "./pages/ProfilePage.jsx";         // ✅ Import ProfilePage

function App() {
  const [account, setAccount] = useState(null);
  const [userRole, setUserRole] = useState(null);
  const prefersDarkMode = useMediaQuery('(prefers-color-scheme: dark)');
  const [mode, setMode] = useState(prefersDarkMode ? 'dark' : 'light');

  // Create a responsive theme that changes with the mode
  const theme = React.useMemo(
    () =>
      createTheme({
        palette: {
          mode,
          primary: {
            main: mode === 'dark' ? '#90caf9' : '#1a237e', // Lighter blue in dark mode
            light: mode === 'dark' ? '#c3fdff' : '#534bae',
            dark: mode === 'dark' ? '#5d99c6' : '#000051',
            contrastText: mode === 'dark' ? '#000000' : '#ffffff',
          },
          secondary: {
            main: mode === 'dark' ? '#69f0ae' : '#4caf50', // Lighter green in dark mode
            light: mode === 'dark' ? '#9fffe0' : '#80e27e',
            dark: mode === 'dark' ? '#2bbd7e' : '#087f23',
            contrastText: mode === 'dark' ? '#000000' : '#ffffff',
          },
          background: {
            default: mode === 'dark' ? '#121212' : '#f5f5f5',
            paper: mode === 'dark' ? '#1e1e1e' : '#ffffff',
          },
        },
        typography: {
          fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
          h1: {
            fontWeight: 700,
          },
          h2: {
            fontWeight: 600,
          },
          h3: {
            fontWeight: 600,
          },
          h4: {
            fontWeight: 600,
          },
          h5: {
            fontWeight: 500,
          },
          h6: {
            fontWeight: 500,
          },
        },
        components: {
          MuiButton: {
            styleOverrides: {
              root: {
                borderRadius: 8,
                textTransform: 'none',
                fontWeight: 500,
              },
            },
          },
          MuiCard: {
            styleOverrides: {
              root: {
                borderRadius: 12,
                boxShadow: mode === 'dark' 
                  ? '0 4px 12px rgba(0,0,0,0.2)' 
                  : '0 4px 12px rgba(0,0,0,0.05)',
              },
            },
          },
          MuiPaper: {
            styleOverrides: {
              root: {
                borderRadius: 12,
              },
            },
          },
        },
      }),
    [mode],
  );

  // Function to update account and role from LoginPage
  const handleLogin = (accountAddress, role) => {
    setAccount(accountAddress);
    setUserRole(role);
  };

  // Listen for theme changes from our ThemeProvider
  const handleThemeChange = (newTheme) => {
    setMode(newTheme);
  };

  return (
    <ThemeProvider defaultTheme="light" onThemeChange={handleThemeChange}>
      <MuiThemeProvider theme={theme}>
        <CssBaseline />
        <Router>
          <Routes>
            <Route path="/" element={<LoginPage onLogin={handleLogin} />} />
            <Route 
              path="/farmer-dashboard" 
              element={
                account ? <FarmerDashboard account={account} /> : <Navigate to="/" />
              } 
            />
            <Route 
              path="/buyer-dashboard" 
              element={
                account ? <BuyerDashboard account={account} /> : <Navigate to="/" />
              } 
            />
            <Route 
              path="/profile" 
              element={
                account ? <ProfilePage account={account} /> : <Navigate to="/" />
              } 
            />
          </Routes>
        </Router>
      </MuiThemeProvider>
    </ThemeProvider>
  );
}

export default App;
