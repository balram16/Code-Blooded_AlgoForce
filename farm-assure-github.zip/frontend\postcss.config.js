export default {
  plugins: {
    // Add postcss plugins here if needed
  }
}; 