# Farm Assure 
A blockchain-based agricultural marketplace. 
## Setup Instructions 
1. Clone the repository 
2. Navigate to the frontend directory: `cd frontend` 
3. Install dependencies: `npm install` 
4. Start the development server: `npm run dev` 
