import { DarkMode as Moon, LightMode as Sun, DarkMode, LightMode } from "@mui/icons-material"
import { useTheme } from "./theme-provider"
import { motion, AnimatePresence } from "framer-motion"

export function ThemeToggle() {
  const { theme, setTheme } = useTheme()
  const isDark = theme === "dark"

  return (
    <motion.button
      whileTap={{ scale: 0.92 }}
      whileHover={{ scale: 1.1 }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ 
        type: "spring", 
        stiffness: 500, 
        damping: 15 
      }}
      onClick={() => setTheme(isDark ? "light" : "dark")}
      className={`
        relative overflow-hidden rounded-full p-2
        bg-gradient-to-br backdrop-blur-md
        ${isDark 
          ? "from-indigo-500/20 to-purple-600/20 text-yellow-300 shadow-lg shadow-indigo-500/20" 
          : "from-amber-300/20 to-yellow-500/20 text-indigo-900 shadow-lg shadow-amber-300/20"
        }
        transform transition-all duration-300 ease-out
        border border-opacity-40
        ${isDark ? "border-indigo-400/30" : "border-amber-400/30"}
      `}
      aria-label="Toggle theme"
    >
      <div className="relative z-10">
        <AnimatePresence mode="wait" initial={false}>
          {isDark ? (
            <motion.div
              key="sun"
              initial={{ rotate: -90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 90, opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Sun className="h-5 w-5" />
            </motion.div>
          ) : (
            <motion.div
              key="moon"
              initial={{ rotate: 90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: -90, opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Moon className="h-5 w-5" />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      <motion.div 
        className="absolute inset-0 rounded-full"
        initial={false}
        animate={{ 
          background: isDark 
            ? "radial-gradient(circle at center, rgba(79, 70, 229, 0.1) 0%, transparent 70%)" 
            : "radial-gradient(circle at center, rgba(251, 191, 36, 0.1) 0%, transparent 70%)" 
        }}
        transition={{ duration: 0.5 }}
      />
    </motion.button>
  )
} 